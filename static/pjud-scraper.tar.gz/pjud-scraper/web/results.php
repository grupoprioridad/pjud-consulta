<?php require_once 'config.php';

$filtro = $_GET['nombre'] ?? '';
$tipo = $_GET['tipo'] ?? '';
$search_id = (int)($_GET['search_id'] ?? 0);
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 50;
$offset = ($page - 1) * $per_page;

$where = [];
$params = [];
if ($filtro) {
  $where[] = "sn.nombre LIKE '%" . mysqli_real_escape_string($db, $filtro) . "%'";
}
if ($tipo) {
  $where[] = "t.tipo = '" . mysqli_real_escape_string($db, $tipo) . "'";
}
if ($search_id) {
  $where[] = "sn.id = $search_id";
}
$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$total = mysqli_fetch_row(mysqli_query($db, "
  SELECT COUNT(*) FROM resultados_causas rc
  JOIN consultas c ON rc.consulta_id = c.id
  JOIN search_names sn ON c.search_name_id = sn.id
  JOIN tribunales t ON c.tribunal_id = t.id
  $where_sql
"))[0];

$causas = mysqli_query($db, "
  SELECT rc.*, sn.nombre as nombre_buscado, t.nombre as tribunal, t.tipo as tribunal_tipo
  FROM resultados_causas rc
  JOIN consultas c ON rc.consulta_id = c.id
  JOIN search_names sn ON c.search_name_id = sn.id
  JOIN tribunales t ON c.tribunal_id = t.id
  $where_sql
  ORDER BY rc.encontrada_en DESC
  LIMIT $per_page OFFSET $offset
");

$nombres_list = mysqli_query($db, "SELECT id, nombre FROM search_names ORDER BY nombre");

$total_pages = ceil($total / $per_page);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PJUD Scraper - Resultados</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container">
    <a class="navbar-brand" href="index.php"><i class="bi bi-search"></i> PJUD Scraper</a>
    <div class="navbar-nav">
      <a class="nav-link" href="index.php">Dashboard</a>
      <a class="nav-link" href="names.php">Nombres</a>
      <a class="nav-link active" href="results.php">Resultados</a>
      <a class="nav-link" href="reports.php">Reportes</a>
    </div>
  </div>
</nav>

<div class="container">
  <h2 class="mb-4"><i class="bi bi-file-earmark-text"></i> Causas encontradas</h2>

  <!-- FILTROS -->
  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <form method="GET" class="row g-2 align-items-end">
        <div class="col-md-4">
          <label class="form-label">Nombre</label>
          <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($filtro) ?>" placeholder="Filtrar por nombre...">
        </div>
        <div class="col-md-3">
          <label class="form-label">Tipo tribunal</label>
          <select name="tipo" class="form-select">
            <option value="">Todos</option>
            <option value="penal" <?= $tipo === 'penal' ? 'selected' : '' ?>>Penal</option>
            <option value="familia" <?= $tipo === 'familia' ? 'selected' : '' ?>>Familia</option>
            <option value="corte" <?= $tipo === 'corte' ? 'selected' : '' ?>>Cortes</option>
            <option value="laboral" <?= $tipo === 'laboral' ? 'selected' : '' ?>>Laboral</option>
            <option value="civil" <?= $tipo === 'civil' ? 'selected' : '' ?>>Civil</option>
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label">Nombre guardado</label>
          <select name="search_id" class="form-select">
            <option value="">Todos</option>
            <?php while ($n = mysqli_fetch_assoc($nombres_list)): ?>
            <option value="<?= $n['id'] ?>" <?= $search_id == $n['id'] ? 'selected' : '' ?>><?= htmlspecialchars($n['nombre']) ?></option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="col-md-2">
          <button type="submit" class="btn btn-primary w-100"><i class="bi bi-funnel"></i> Filtrar</button>
        </div>
      </form>
    </div>
  </div>

  <p class="text-muted"><?= number_format($total) ?> causas encontradas</p>

  <!-- TABLA -->
  <div class="card shadow-sm">
    <div class="card-body p-0">
      <table class="table table-hover mb-0">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Buscado</th>
            <th>RIT</th>
            <th>Caratulado</th>
            <th>Tribunal</th>
            <th>Tipo</th>
            <th>Estado</th>
            <th>Ingreso</th>
            <th>Hallazgo</th>
          </tr>
        </thead>
        <tbody>
          <?php if (mysqli_num_rows($causas) > 0): ?>
            <?php $i = $offset + 1; while ($c = mysqli_fetch_assoc($causas)): ?>
            <tr class="<?= $c['es_nueva'] ? 'table-success' : '' ?>">
              <td><?= $i++ ?></td>
              <td><strong><?= htmlspecialchars($c['nombre_buscado']) ?></strong></td>
              <td><code><?= htmlspecialchars($c['rit'] ?? '-') ?></code></td>
              <td><small><?= htmlspecialchars(mb_substr($c['caratulado'] ?? '-', 0, 60)) ?></small></td>
              <td><small><?= htmlspecialchars(mb_substr($c['tribunal'] ?? '-', 0, 30)) ?></small></td>
              <td><span class="badge bg-<?= $c['tribunal_tipo'] == 'penal' ? 'danger' : ($c['tribunal_tipo'] == 'familia' ? 'info' : 'secondary') ?>"><?= $c['tribunal_tipo'] ?></span></td>
              <td><span class="badge bg-<?= $c['estado'] == 'ACTIVO' ? 'danger' : 'secondary' ?>"><?= htmlspecialchars($c['estado'] ?? '-') ?></span></td>
              <td><small><?= $c['fecha_ingreso'] ? date('d/m/Y', strtotime($c['fecha_ingreso'])) : '-' ?></small></td>
              <td><small><?= date('d/m/Y H:i', strtotime($c['encontrada_en'])) ?></small></td>
            </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="9" class="text-center text-muted py-4">No se encontraron causas con estos filtros.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- PAGINACIÓN -->
  <?php if ($total_pages > 1): ?>
  <nav class="mt-3">
    <ul class="pagination justify-content-center">
      <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
        <a class="page-link" href="?page=<?= $page-1 ?>&nombre=<?= urlencode($filtro) ?>&tipo=<?= $tipo ?>&search_id=<?= $search_id ?>">Anterior</a>
      </li>
      <?php for ($p = max(1, $page-2); $p <= min($total_pages, $page+2); $p++): ?>
      <li class="page-item <?= $p == $page ? 'active' : '' ?>">
        <a class="page-link" href="?page=<?= $p ?>&nombre=<?= urlencode($filtro) ?>&tipo=<?= $tipo ?>&search_id=<?= $search_id ?>"><?= $p ?></a>
      </li>
      <?php endfor; ?>
      <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
        <a class="page-link" href="?page=<?= $page+1 ?>&nombre=<?= urlencode($filtro) ?>&tipo=<?= $tipo ?>&search_id=<?= $search_id ?>">Siguiente</a>
      </li>
    </ul>
  </nav>
  <?php endif; ?>

  <!-- EXPORTAR -->
  <div class="mt-3 mb-4">
    <a href="export.php?nombre=<?= urlencode($filtro) ?>&tipo=<?= $tipo ?>&search_id=<?= $search_id ?>&format=csv" class="btn btn-outline-success">
      <i class="bi bi-download"></i> Exportar CSV
    </a>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
