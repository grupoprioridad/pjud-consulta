<?php require_once 'config.php';

// Acciones
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_GET['action'] ?? '';

  if ($action === 'add' && !empty($_POST['nombre'])) {
    $nombre = mysqli_real_escape_string($db, trim($_POST['nombre']));
    $rut = !empty($_POST['rut']) ? "'" . mysqli_real_escape_string($db, $_POST['rut']) . "'" : 'NULL';
    $prioridad = (int)($_POST['prioridad'] ?? 5);

    // Verificar si ya existe
    $existe = mysqli_query($db, "SELECT id FROM search_names WHERE nombre = '$nombre'");
    if (mysqli_num_rows($existe) == 0) {
      mysqli_query($db, "INSERT INTO search_names (nombre, rut, prioridad) VALUES ('$nombre', $rut, $prioridad)");
      $new_id = mysqli_insert_id($db);

      // Crear consultas pendientes para todos los tribunales activos
      $tribunales = mysqli_query($db, "SELECT id FROM tribunales WHERE activo = 1");
      while ($t = mysqli_fetch_assoc($tribunales)) {
        mysqli_query($db, "INSERT INTO consultas (search_name_id, tribunal_id, estado) VALUES ($new_id, {$t['id']}, 'pendiente')");
      }
      $_SESSION['msg'] = "Nombre '$nombre' agregado con " . mysqli_affected_rows($db) . " consultas pendientes.";
    } else {
      $_SESSION['msg'] = "El nombre '$nombre' ya existe.";
    }
  }

  if ($action === 'toggle' && isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    $r = mysqli_fetch_assoc(mysqli_query($db, "SELECT activo FROM search_names WHERE id=$id"));
    if ($r) {
      $nuevo = $r['activo'] ? 0 : 1;
      mysqli_query($db, "UPDATE search_names SET activo=$nuevo WHERE id=$id");
      $_SESSION['msg'] = "Estado actualizado.";
    }
  }

  if ($action === 'delete' && isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    mysqli_query($db, "DELETE FROM search_names WHERE id=$id");
    $_SESSION['msg'] = "Nombre eliminado.";
  }

  if ($action === 'reiniciar' && isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    mysqli_query($db, "UPDATE consultas SET estado='pendiente', intentos=0, error_msg=NULL WHERE search_name_id=$id AND estado IN ('error','sin_resultados')");
    $_SESSION['msg'] = "Consultas reiniciadas.";
  }

  header("Location: names.php");
  exit;
}

$msg = $_SESSION['msg'] ?? '';
unset($_SESSION['msg']);

$nombres = mysqli_query($db, "
  SELECT sn.*,
    (SELECT COUNT(*) FROM consultas WHERE search_name_id=sn.id) as total_consultas,
    (SELECT COUNT(*) FROM consultas WHERE search_name_id=sn.id AND estado='pendiente') as pendientes,
    (SELECT COUNT(*) FROM consultas WHERE search_name_id=sn.id AND estado='completado') as completadas,
    (SELECT COUNT(*) FROM consultas WHERE search_name_id=sn.id AND estado='error') as errores,
    (SELECT COUNT(*) FROM resultados_causas rc JOIN consultas c ON rc.consulta_id=c.id WHERE c.search_name_id=sn.id) as causas
  FROM search_names sn
  ORDER BY sn.prioridad ASC, sn.nombre ASC
");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PJUD Scraper - Nombres</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container">
    <a class="navbar-brand" href="index.php"><i class="bi bi-search"></i> PJUD Scraper</a>
    <div class="navbar-nav">
      <a class="nav-link" href="index.php">Dashboard</a>
      <a class="nav-link active" href="names.php">Nombres</a>
      <a class="nav-link" href="results.php">Resultados</a>
      <a class="nav-link" href="reports.php">Reportes</a>
    </div>
  </div>
</nav>

<div class="container">
  <h2 class="mb-4"><i class="bi bi-person-lines-fill"></i> Nombres a buscar</h2>

  <?php if ($msg): ?>
  <div class="alert alert-success alert-dismissible fade show"><?= htmlspecialchars($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
  <?php endif; ?>

  <!-- FORMULARIO AGREGAR -->
  <div class="card shadow-sm mb-4">
    <div class="card-header"><h5 class="mb-0"><i class="bi bi-plus-circle"></i> Agregar nombre</h5></div>
    <div class="card-body">
      <form method="POST" action="?action=add" class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Nombre completo <span class="text-danger">*</span></label>
          <input type="text" name="nombre" class="form-control" placeholder="Ej: Juan Pérez González" required>
        </div>
        <div class="col-md-3">
          <label class="form-label">RUT (opcional)</label>
          <input type="text" name="rut" class="form-control" placeholder="Ej: 12.345.678-9">
        </div>
        <div class="col-md-2">
          <label class="form-label">Prioridad</label>
          <select name="prioridad" class="form-select">
            <option value="1">1 - Alta</option>
            <option value="3">3</option>
            <option value="5" selected>5 - Normal</option>
            <option value="7">7</option>
            <option value="10">10 - Baja</option>
          </select>
        </div>
        <div class="col-md-1 d-flex align-items-end">
          <button type="submit" class="btn btn-success w-100"><i class="bi bi-search"></i></button>
        </div>
      </form>
    </div>
  </div>

  <!-- LISTA DE NOMBRES -->
  <div class="card shadow-sm">
    <div class="card-header"><h5 class="mb-0"><i class="bi bi-list"></i> Nombres registrados</h5></div>
    <div class="card-body p-0">
      <table class="table table-hover mb-0">
        <thead class="table-light">
          <tr>
            <th>Nombre</th>
            <th>RUT</th>
            <th>Prioridad</th>
            <th>Consultas</th>
            <th>Causas</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php if (mysqli_num_rows($nombres) > 0): ?>
            <?php while ($n = mysqli_fetch_assoc($nombres)): ?>
            <tr class="<?= !$n['activo'] ? 'table-secondary' : '' ?>">
              <td><strong><?= htmlspecialchars($n['nombre']) ?></strong></td>
              <td><code><?= htmlspecialchars($n['rut'] ?? '-') ?></code></td>
              <td><span class="badge bg-<?= $n['prioridad'] <= 3 ? 'danger' : ($n['prioridad'] <= 6 ? 'warning text-dark' : 'secondary') ?>"><?= $n['prioridad'] ?></span></td>
              <td>
                <span class="badge bg-secondary"><?= $n['total_consultas'] ?></span>
                <span class="badge bg-warning text-dark"><?= $n['pendientes'] ?> pend.</span>
                <span class="badge bg-success"><?= $n['completadas'] ?> ok</span>
                <?php if ($n['errores'] > 0): ?>
                  <span class="badge bg-danger"><?= $n['errores'] ?> err</span>
                <?php endif; ?>
              </td>
              <td><span class="badge bg-info"><?= $n['causas'] ?></span></td>
              <td>
                <?php if ($n['activo']): ?>
                  <span class="badge bg-success">Activo</span>
                <?php else: ?>
                  <span class="badge bg-secondary">Inactivo</span>
                <?php endif; ?>
              </td>
              <td>
                <form method="POST" action="?action=toggle" class="d-inline">
                  <input type="hidden" name="id" value="<?= $n['id'] ?>">
                  <button class="btn btn-sm btn-outline-<?= $n['activo'] ? 'warning' : 'success' ?>"
                    title="<?= $n['activo'] ? 'Desactivar' : 'Activar' ?>">
                    <i class="bi bi-<?= $n['activo'] ? 'pause-circle' : 'play-circle' ?>"></i>
                  </button>
                </form>
                <form method="POST" action="?action=reiniciar" class="d-inline">
                  <input type="hidden" name="id" value="<?= $n['id'] ?>">
                  <button class="btn btn-sm btn-outline-info" title="Reiniciar consultas fallidas"><i class="bi bi-arrow-clockwise"></i></button>
                </form>
                <form method="POST" action="?action=delete" class="d-inline" onsubmit="return confirm('¿Eliminar <?= htmlspecialchars(addslashes($n['nombre'])) ?>?')">
                  <input type="hidden" name="id" value="<?= $n['id'] ?>">
                  <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr><td colspan="7" class="text-center text-muted py-4">No hay nombres registrados. ¡Agrega el primero arriba!</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
