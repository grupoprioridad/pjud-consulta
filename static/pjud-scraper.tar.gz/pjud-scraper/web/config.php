<?php
/**
 * Configuración para la interfaz web del PJUD Scraper
 */
session_start();

$configPath = __DIR__ . '/../config/config.json';
if (!file_exists($configPath)) {
  die('Config file not found at: ' . $configPath);
}
$config = json_decode(file_get_contents($configPath), true);
if (!$config) {
  die('Invalid config JSON');
}

// Conexión MySQL
$db = mysqli_connect(
  $config['db']['host'],
  $config['db']['user'],
  $config['db']['password'],
  $config['db']['database'],
  $config['db']['port']
);

if (!$db) {
  die('Error de conexión: ' . mysqli_connect_error());
}

mysqli_set_charset($db, 'utf8mb4');
