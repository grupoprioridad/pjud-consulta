<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PJUD Scraper - Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container">
    <a class="navbar-brand" href="#"><i class="bi bi-search"></i> PJUD Scraper</a>
    <div class="navbar-nav">
      <a class="nav-link active" href="index.php">Dashboard</a>
      <a class="nav-link" href="names.php">Nombres</a>
      <a class="nav-link" href="results.php">Resultados</a>
      <a class="nav-link" href="reports.php">Reportes</a>
    </div>
  </div>
</nav>

<div class="container">
  <h2 class="mb-4"><i class="bi bi-speedometer2"></i> Dashboard</h2>

  <?php
  // Estadísticas
  $total_names = mysqli_fetch_row(mysqli_query($db, "SELECT COUNT(*) FROM search_names"))[0];
  $active_names = mysqli_fetch_row(mysqli_query($db, "SELECT COUNT(*) FROM search_names WHERE activo=1"))[0];
  $total_causas = mysqli_fetch_row(mysqli_query($db, "SELECT COUNT(*) FROM resultados_causas"))[0];
  $causas_nuevas = mysqli_fetch_row(mysqli_query($db, "SELECT COUNT(*) FROM resultados_causas WHERE es_nueva=1"))[0];
  $total_consultas = mysqli_fetch_row(mysqli_query($db, "SELECT COUNT(*) FROM consultas"))[0];
  $consultas_hoy = mysqli_fetch_row(mysqli_query($db, "SELECT COUNT(*) FROM consultas WHERE DATE(fecha_consulta)=CURDATE()"))[0];
  $tribunales_activos = mysqli_fetch_row(mysqli_query($db, "SELECT COUNT(*) FROM tribunales WHERE activo=1"))[0];

  // Últimas causas encontradas
  $ultimas_causas = mysqli_query($db, "
    SELECT rc.*, sn.nombre as nombre_buscado
    FROM resultados_causas rc
    JOIN consultas c ON rc.consulta_id = c.id
    JOIN search_names sn ON c.search_name_id = sn.id
    ORDER BY rc.encontrada_en DESC
    LIMIT 10
  ");

  // Próximas búsquedas pendientes
  $pendientes = mysqli_query($db, "
    SELECT sn.nombre, COUNT(*) as pendientes
    FROM consultas c
    JOIN search_names sn ON c.search_name_id = sn.id
    WHERE c.estado = 'pendiente'
    GROUP BY sn.nombre
    ORDER BY pendientes DESC
    LIMIT 10
  ");
  ?>

  <!-- TARJETAS DE RESUMEN -->
  <div class="row g-3 mb-4">
    <div class="col-md-3">
      <div class="card border-primary">
        <div class="card-body text-center">
          <h5 class="card-title text-primary"><i class="bi bi-person"></i> <?= $active_names ?></h5>
          <p class="card-text">Nombres activos <small class="text-muted">(<?= $total_names ?> total)</small></p>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card border-success">
        <div class="card-body text-center">
          <h5 class="card-title text-success"><i class="bi bi-building"></i> <?= $tribunales_activos ?></h5>
          <p class="card-text">Tribunales monitoreados</p>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card border-info">
        <div class="card-body text-center">
          <h5 class="card-title text-info"><i class="bi bi-file-earmark-text"></i> <?= $total_causas ?></h5>
          <p class="card-text">Causas encontradas <small class="text-muted">(<?= $causas_nuevas ?> nuevas)</small></p>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card border-warning">
        <div class="card-body text-center">
          <h5 class="card-title text-warning"><i class="bi bi-clock-history"></i> <?= $consultas_hoy ?></h5>
          <p class="card-text">Consultas hoy <small class="text-muted">(<?= $total_consultas ?> total)</small></p>
        </div>
      </div>
    </div>
  </div>

  <div class="row g-4">
    <!-- ÚLTIMAS CAUSAS -->
    <div class="col-md-7">
      <div class="card shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h5 class="mb-0"><i class="bi bi-list-ul"></i> Últimas causas encontradas</h5>
          <a href="results.php" class="btn btn-sm btn-outline-primary">Ver todas</a>
        </div>
        <div class="card-body p-0">
          <table class="table table-hover mb-0">
            <thead class="table-light">
              <tr>
                <th>Nombre buscado</th>
                <th>RIT</th>
                <th>Caratulado</th>
                <th>Estado</th>
                <th>Fecha</th>
              </tr>
            </thead>
            <tbody>
              <?php if (mysqli_num_rows($ultimas_causas) > 0): ?>
                <?php while ($c = mysqli_fetch_assoc($ultimas_causas)): ?>
                <tr class="<?= $c['es_nueva'] ? 'table-success' : '' ?>">
                  <td><strong><?= htmlspecialchars($c['nombre_buscado']) ?></strong></td>
                  <td><code><?= htmlspecialchars($c['rit'] ?? '-') ?></code></td>
                  <td><small><?= htmlspecialchars(mb_substr($c['caratulado'] ?? '-', 0, 50)) ?></small></td>
                  <td><span class="badge bg-<?= $c['estado'] == 'ACTIVO' ? 'danger' : 'secondary' ?>"><?= htmlspecialchars($c['estado'] ?? '-') ?></span></td>
                  <td><small><?= date('d/m/Y', strtotime($c['encontrada_en'])) ?></small></td>
                </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="5" class="text-center text-muted py-3">Aún no hay resultados. Agrega nombres y ejecuta el scraper.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- BÚSQUEDAS PENDIENTES -->
    <div class="col-md-5">
      <div class="card shadow-sm">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h5 class="mb-0"><i class="bi bi-hourglass-split"></i> Búsquedas pendientes</h5>
          <a href="names.php" class="btn btn-sm btn-outline-success">+ Agregar</a>
        </div>
        <div class="card-body p-0">
          <table class="table table-hover mb-0">
            <thead class="table-light">
              <tr><th>Nombre</th><th>Pendientes</th></tr>
            </thead>
            <tbody>
              <?php if (mysqli_num_rows($pendientes) > 0): ?>
                <?php while ($p = mysqli_fetch_assoc($pendientes)): ?>
                <tr>
                  <td><?= htmlspecialchars($p['nombre']) ?></td>
                  <td><span class="badge bg-warning text-dark"><?= $p['pendientes'] ?></span></td>
                </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr><td colspan="2" class="text-center text-muted py-3">No hay búsquedas pendientes.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- CARGA RÁPIDA -->
      <div class="card shadow-sm mt-3">
        <div class="card-header">
          <h5 class="mb-0"><i class="bi bi-plus-circle"></i> Carga rápida de nombre</h5>
        </div>
        <div class="card-body">
          <form method="POST" action="names.php?action=add">
            <div class="input-group">
              <input type="text" name="nombre" class="form-control" placeholder="Nombre a buscar..." required>
              <button class="btn btn-success" type="submit"><i class="bi bi-search"></i> Buscar</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
