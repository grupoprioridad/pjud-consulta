<?php
require_once 'config.php';

$filtro = $_GET['nombre'] ?? '';
$tipo = $_GET['tipo'] ?? '';
$search_id = (int)($_GET['search_id'] ?? 0);
$format = $_GET['format'] ?? 'csv';

$where = [];
if ($filtro) {
  $where[] = "sn.nombre LIKE '%" . mysqli_real_escape_string($db, $filtro) . "%'";
}
if ($tipo) {
  $where[] = "t.tipo = '" . mysqli_real_escape_string($db, $tipo) . "'";
}
if ($search_id) {
  $where[] = "sn.id = $search_id";
}
$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$result = mysqli_query($db, "
  SELECT rc.rit, rc.caratulado, rc.estado as estado_causa,
         rc.fecha_ingreso, rc.encontrada_en,
         sn.nombre as nombre_buscado,
         t.nombre as tribunal, t.tipo as tribunal_tipo
  FROM resultados_causas rc
  JOIN consultas c ON rc.consulta_id = c.id
  JOIN search_names sn ON c.search_name_id = sn.id
  JOIN tribunales t ON c.tribunal_id = t.id
  $where_sql
  ORDER BY rc.encontrada_en DESC
");

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="pjud_causas_' . date('Ymd') . '.csv"');

$out = fopen('php://output', 'w');
fprintf($out, "\xEF\xBB\xBF"); // BOM UTF-8
fputcsv($out, ['Nombre Buscado', 'RIT', 'Caratulado', 'Tribunal', 'Tipo', 'Estado Causa', 'Fecha Ingreso', 'Fecha Hallazgo']);

while ($row = mysqli_fetch_assoc($result)) {
  fputcsv($out, [
    $row['nombre_buscado'],
    $row['rit'],
    $row['caratulado'],
    $row['tribunal'],
    $row['tribunal_tipo'],
    $row['estado_causa'],
    $row['fecha_ingreso'],
    $row['encontrada_en']
  ]);
}
fclose($out);
exit;
