<?php require_once 'config.php';

// Generar reporte manual
if (isset($_GET['generate'])) {
  $tipo = $_GET['tipo'] ?? 'semanal';
  $formato = $_GET['formato'] ?? 'html';
  $desde = $_GET['desde'] ?? date('Y-m-d', strtotime('-7 days'));
  $hasta = $_GET['hasta'] ?? date('Y-m-d');

  $total_busquedas = mysqli_fetch_row(mysqli_query($db, "
    SELECT COUNT(*) FROM consultas WHERE DATE(fecha_consulta) BETWEEN '$desde' AND '$hasta'
  "))[0];
  $total_causas = mysqli_fetch_row(mysqli_query($db, "
    SELECT COUNT(*) FROM resultados_causas WHERE DATE(encontrada_en) BETWEEN '$desde' AND '$hasta'
  "))[0];
  $causas_nuevas = mysqli_fetch_row(mysqli_query($db, "
    SELECT COUNT(*) FROM resultados_causas WHERE es_nueva=1 AND DATE(encontrada_en) BETWEEN '$desde' AND '$hasta'
  "))[0];

  // Guardar en DB
  mysqli_query($db, "INSERT INTO reportes (tipo, formato, desde, hasta, total_busquedas, total_causas, causas_nuevas)
    VALUES ('$tipo', '$formato', '$desde', '$hasta', $total_busquedas, $total_causas, $causas_nuevas)");
  $reporte_id = mysqli_insert_id($db);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PJUD Scraper - Reportes</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
  <div class="container">
    <a class="navbar-brand" href="index.php"><i class="bi bi-search"></i> PJUD Scraper</a>
    <div class="navbar-nav">
      <a class="nav-link" href="index.php">Dashboard</a>
      <a class="nav-link" href="names.php">Nombres</a>
      <a class="nav-link" href="results.php">Resultados</a>
      <a class="nav-link active" href="reports.php">Reportes</a>
    </div>
  </div>
</nav>

<div class="container">
  <h2 class="mb-4"><i class="bi bi-bar-chart-fill"></i> Reportes</h2>

  <!-- GENERAR REPORTE -->
  <div class="card shadow-sm mb-4">
    <div class="card-header"><h5 class="mb-0"><i class="bi bi-plus-circle"></i> Generar reporte</h5></div>
    <div class="card-body">
      <form method="GET" class="row g-3">
        <div class="col-md-3">
          <label class="form-label">Tipo</label>
          <select name="tipo" class="form-select">
            <option value="diario">Diario</option>
            <option value="semanal" selected>Semanal</option>
            <option value="mensual">Mensual</option>
            <option value="manual">Manual</option>
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label">Desde</label>
          <input type="date" name="desde" class="form-control" value="<?= date('Y-m-d', strtotime('-7 days')) ?>">
        </div>
        <div class="col-md-3">
          <label class="form-label">Hasta</label>
          <input type="date" name="hasta" class="form-control" value="<?= date('Y-m-d') ?>">
        </div>
        <div class="col-md-2">
          <label class="form-label">Formato</label>
          <select name="formato" class="form-select">
            <option value="html">HTML</option>
            <option value="csv">CSV</option>
          </select>
        </div>
        <div class="col-md-1 d-flex align-items-end">
          <button type="submit" name="generate" value="1" class="btn btn-primary w-100"><i class="bi bi-file-earmark"></i></button>
        </div>
      </form>
    </div>
  </div>

  <!-- GRÁFICO DE CAUSAS POR DÍA -->
  <div class="row g-4 mb-4">
    <div class="col-md-8">
      <div class="card shadow-sm">
        <div class="card-header"><h5 class="mb-0"><i class="bi bi-graph-up"></i> Causas encontradas por día</h5></div>
        <div class="card-body">
          <canvas id="causasChart" height="200"></canvas>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-header"><h5 class="mb-0"><i class="bi bi-pie-chart"></i> Por tipo de tribunal</h5></div>
        <div class="card-body">
          <canvas id="tipoChart" height="200"></canvas>
        </div>
      </div>
    </div>
  </div>

  <?php
  // Datos para gráficos
  $causas_por_dia = mysqli_query($db, "
    SELECT DATE(encontrada_en) as fecha, COUNT(*) as total
    FROM resultados_causas
    WHERE encontrada_en >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY DATE(encontrada_en)
    ORDER BY fecha ASC
  ");
  $dias = []; $totales = [];
  while ($d = mysqli_fetch_assoc($causas_por_dia)) {
    $dias[] = $d['fecha'];
    $totales[] = (int)$d['total'];
  }

  $causas_por_tipo = mysqli_query($db, "
    SELECT t.tipo, COUNT(*) as total
    FROM resultados_causas rc
    JOIN consultas c ON rc.consulta_id = c.id
    JOIN tribunales t ON c.tribunal_id = t.id
    GROUP BY t.tipo
  ");
  $tipos = []; $tipos_totales = [];
  while ($t = mysqli_fetch_assoc($causas_por_tipo)) {
    $tipos[] = $t['tipo'];
    $tipos_totales[] = (int)$t['total'];
  }
  ?>

  <!-- HISTORIAL DE REPORTES -->
  <div class="card shadow-sm">
    <div class="card-header"><h5 class="mb-0"><i class="bi bi-clock-history"></i> Reportes generados</h5></div>
    <div class="card-body p-0">
      <table class="table table-hover mb-0">
        <thead class="table-light">
          <tr>
            <th>Fecha</th>
            <th>Tipo</th>
            <th>Período</th>
            <th>Búsquedas</th>
            <th>Causas</th>
            <th>Nuevas</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $reportes = mysqli_query($db, "SELECT * FROM reportes ORDER BY created_at DESC LIMIT 20");
          if (mysqli_num_rows($reportes) > 0):
            while ($r = mysqli_fetch_assoc($reportes)):
          ?>
          <tr>
            <td><small><?= date('d/m/Y H:i', strtotime($r['created_at'])) ?></small></td>
            <td><span class="badge bg-primary"><?= $r['tipo'] ?></span></td>
            <td><small><?= date('d/m/Y', strtotime($r['desde'])) ?> - <?= date('d/m/Y', strtotime($r['hasta'])) ?></small></td>
            <td><?= number_format($r['total_busquedas']) ?></td>
            <td><?= number_format($r['total_causas']) ?></td>
            <td><span class="badge bg-success"><?= $r['causas_nuevas'] ?> nuevas</span></td>
          </tr>
          <?php
            endwhile;
          else:
          ?>
          <tr><td colspan="6" class="text-center text-muted py-3">Aún no hay reportes generados.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
const ctx1 = document.getElementById('causasChart').getContext('2d');
new Chart(ctx1, {
  type: 'bar',
  data: {
    labels: <?= json_encode($dias) ?>,
    datasets: [{
      label: 'Causas encontradas',
      data: <?= json_encode($totales) ?>,
      backgroundColor: 'rgba(13, 110, 253, 0.5)',
      borderColor: 'rgba(13, 110, 253, 1)',
      borderWidth: 1
    }]
  },
  options: {
    responsive: true,
    scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
  }
});

const ctx2 = document.getElementById('tipoChart').getContext('2d');
new Chart(ctx2, {
  type: 'doughnut',
  data: {
    labels: <?= json_encode($tipos) ?>,
    datasets: [{
      data: <?= json_encode($tipos_totales) ?>,
      backgroundColor: ['#dc3545', '#0d6efd', '#6f42c1', '#198754', '#ffc107']
    }]
  }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
