-- =============================================
-- PJUD Scraper - Esquema de Base de Datos
-- =============================================

CREATE DATABASE IF NOT EXISTS pjud_scraper
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE pjud_scraper;

-- Nombres a buscar
CREATE TABLE search_names (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  nombre     VARCHAR(200) NOT NULL,
  rut        VARCHAR(20) DEFAULT NULL,
  activo     TINYINT(1) DEFAULT 1,
  prioridad  INT DEFAULT 5,  -- 1 (alta) a 10 (baja)
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_nombre (nombre),
  INDEX idx_activo (activo)
) ENGINE=InnoDB;

-- Tribunales disponibles
CREATE TABLE tribunales (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  nombre       VARCHAR(200) NOT NULL,
  codigo       VARCHAR(50) NOT NULL UNIQUE,
  tipo         ENUM('penal','familia','corte','laboral','civil','garantia') NOT NULL,
  region       VARCHAR(100) DEFAULT NULL,
  activo       TINYINT(1) DEFAULT 1,
  UNIQUE INDEX idx_codigo (codigo)
) ENGINE=InnoDB;

-- Registro de cada consulta ejecutada
CREATE TABLE consultas (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  search_name_id  INT NOT NULL,
  tribunal_id     INT NOT NULL,
  estado          ENUM('pendiente','procesando','completado','error','sin_resultados') DEFAULT 'pendiente',
  fecha_consulta  DATETIME DEFAULT NULL,
  duracion_seg    INT DEFAULT NULL,
  ip_utilizada    VARCHAR(45) DEFAULT NULL,
  error_msg       TEXT DEFAULT NULL,
  intentos        INT DEFAULT 0,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (search_name_id) REFERENCES search_names(id) ON DELETE CASCADE,
  FOREIGN KEY (tribunal_id) REFERENCES tribunales(id) ON DELETE CASCADE,
  INDEX idx_estado (estado),
  INDEX idx_fecha (fecha_consulta),
  INDEX idx_search_tribunal (search_name_id, tribunal_id)
) ENGINE=InnoDB;

-- Resultados de causas encontradas
CREATE TABLE resultados_causas (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  consulta_id     INT NOT NULL,
  rit             VARCHAR(100) DEFAULT NULL,
  caratulado      VARCHAR(500) DEFAULT NULL,
  tribunal_nombre VARCHAR(200) DEFAULT NULL,
  tipo_causa      VARCHAR(100) DEFAULT NULL,
  estado          VARCHAR(100) DEFAULT NULL,
  fecha_ingreso   DATE DEFAULT NULL,
  url_detalle     VARCHAR(500) DEFAULT NULL,
  raw_html        LONGTEXT DEFAULT NULL,
  encontrada_en   DATETIME DEFAULT CURRENT_TIMESTAMP,
  es_nueva        TINYINT(1) DEFAULT 1,
  FOREIGN KEY (consulta_id) REFERENCES consultas(id) ON DELETE CASCADE,
  INDEX idx_rit (rit),
  INDEX idx_estado (estado),
  INDEX idx_fecha_ingreso (fecha_ingreso),
  INDEX idx_es_nueva (es_nueva)
) ENGINE=InnoDB;

-- Reportes generados
CREATE TABLE reportes (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  tipo        ENUM('diario','semanal','mensual','manual') NOT NULL,
  formato     ENUM('html','csv','pdf') DEFAULT 'html',
  desde       DATE NOT NULL,
  hasta       DATE NOT NULL,
  total_busquedas INT DEFAULT 0,
  total_causas    INT DEFAULT 0,
  causas_nuevas   INT DEFAULT 0,
  archivo     VARCHAR(500) DEFAULT NULL,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Log de actividad del scraper
CREATE TABLE scraper_log (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  nivel       ENUM('info','warning','error','debug') DEFAULT 'info',
  mensaje     TEXT NOT NULL,
  consulta_id INT DEFAULT NULL,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_nivel (nivel),
  INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- =============================================
-- Datos iniciales: Tribunales chilenos
-- =============================================

INSERT INTO tribunales (nombre, codigo, tipo, region) VALUES
-- CORTES DE APELACIONES
('Corte Suprema', 'CORTE_SUPREMA', 'corte', 'Nacional'),
('Corte de Apelaciones de Santiago', 'CORTE_SANTIAGO', 'corte', 'Metropolitana'),
('Corte de Apelaciones de San Miguel', 'CORTE_SAN_MIGUEL', 'corte', 'Metropolitana'),
('Corte de Apelaciones de Valparaíso', 'CORTE_VALPARAISO', 'corte', 'Valparaíso'),
('Corte de Apelaciones de Concepción', 'CORTE_CONCEPCION', 'corte', 'Bío-Bío'),
('Corte de Apelaciones de Rancagua', 'CORTE_RANCAGUA', 'corte', "O'Higgins"),
('Corte de Apelaciones de Talca', 'CORTE_TALCA', 'corte', 'Maule'),
('Corte de Apelaciones de Temuco', 'CORTE_TEMUCO', 'corte', 'Araucanía'),
('Corte de Apelaciones de La Serena', 'CORTE_SERENA', 'corte', 'Coquimbo'),
('Corte de Apelaciones de Antofagasta', 'CORTE_ANTOFAGASTA', 'corte', 'Antofagasta'),
-- PENAL
('1° Juzgado de Garantía de Santiago', 'JGDO_GARANTIA_1_SANTIAGO', 'penal', 'Metropolitana'),
('2° Juzgado de Garantía de Santiago', 'JGDO_GARANTIA_2_SANTIAGO', 'penal', 'Metropolitana'),
('3° Juzgado de Garantía de Santiago', 'JGDO_GARANTIA_3_SANTIAGO', 'penal', 'Metropolitana'),
('4° Juzgado de Garantía de Santiago', 'JGDO_GARANTIA_4_SANTIAGO', 'penal', 'Metropolitana'),
('7° Juzgado de Garantía de Santiago', 'JGDO_GARANTIA_7_SANTIAGO', 'penal', 'Metropolitana'),
('Tribunal Oral en lo Penal de Santiago', 'TOP_SANTIAGO', 'penal', 'Metropolitana'),
('Juzgado de Garantía de Viña del Mar', 'JGDO_GARANTIA_VINA', 'penal', 'Valparaíso'),
('Juzgado de Garantía de Valparaíso', 'JGDO_GARANTIA_VALPO', 'penal', 'Valparaíso'),
('Juzgado de Garantía de Concepción', 'JGDO_GARANTIA_CONCE', 'penal', 'Bío-Bío'),
('Juzgado de Garantía de Temuco', 'JGDO_GARANTIA_TEMUCO', 'penal', 'Araucanía'),
('Juzgado de Garantía de Rancagua', 'JGDO_GARANTIA_RANCA', 'penal', "O'Higgins"),
('Juzgado de Garantía de Talca', 'JGDO_GARANTIA_TALCA', 'penal', 'Maule'),
('Juzgado de Garantía de La Serena', 'JGDO_GARANTIA_SERENA', 'penal', 'Coquimbo'),
('Juzgado de Garantía de Antofagasta', 'JGDO_GARANTIA_ANTOFA', 'penal', 'Antofagasta'),
-- FAMILIA
('1° Juzgado de Familia de Santiago', 'FLIA_1_SANTIAGO', 'familia', 'Metropolitana'),
('2° Juzgado de Familia de Santiago', 'FLIA_2_SANTIAGO', 'familia', 'Metropolitana'),
('3° Juzgado de Familia de Santiago', 'FLIA_3_SANTIAGO', 'familia', 'Metropolitana'),
('Juzgado de Familia de Viña del Mar', 'FLIA_VINA', 'familia', 'Valparaíso'),
('Juzgado de Familia de Valparaíso', 'FLIA_VALPO', 'familia', 'Valparaíso'),
('Juzgado de Familia de Concepción', 'FLIA_CONCE', 'familia', 'Bío-Bío'),
('Juzgado de Familia de Temuco', 'FLIA_TEMUCO', 'familia', 'Araucanía'),
('Juzgado de Familia de Rancagua', 'FLIA_RANCA', 'familia', "O'Higgins"),
('Juzgado de Familia de Talca', 'FLIA_TALCA', 'familia', 'Maule'),
('Juzgado de Familia de La Serena', 'FLIA_SERENA', 'familia', 'Coquimbo'),
('Juzgado de Familia de Antofagasta', 'FLIA_ANTOFA', 'familia', 'Antofagasta'),
('Juzgado de Familia de Pucón', 'FLIA_PUCON', 'familia', 'Araucanía');
