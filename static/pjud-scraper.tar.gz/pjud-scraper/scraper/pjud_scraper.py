#!/usr/bin/env python3
"""
PJUD Scraper - Buscador automático de causas judiciales
Oficina Judicial Virtual - Poder Judicial de Chile

Uso:
  python3 pjud_scraper.py                        # Ejecuta cola de pendientes
  python3 pjud_scraper.py --name "Juan Perez"    # Busca nombre específico
  python3 pjud_scraper.py --save-cookies cookies.pkl  # Guarda cookies
  python3 pjud_scraper.py --test                 # Prueba conexión
  python3 pjud_scraper.py --daemon               # Modo loop continuo
"""

import os, sys, json, time, random, logging, argparse, datetime, traceback, re, pickle
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / 'config' / 'config.json'

with open(CONFIG_PATH) as f:
    CONFIG = json.load(f)

DB_CONFIG = CONFIG['db']
SCRAPER_CONFIG = CONFIG['scraper']

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.StreamHandler(), logging.FileHandler(str(BASE_DIR / 'scraper' / 'scraper.log'))]
)
log = logging.getLogger('pjud')

# ─── DB ─────────────────────────────────────────────────────────────────
DB_CONN = None
def db_connect():
    global DB_CONN
    if DB_CONN and DB_CONN.open:
        try: DB_CONN.ping(); return DB_CONN
        except: pass
    import pymysql
    DB_CONN = pymysql.connect(host=DB_CONFIG['host'], port=DB_CONFIG['port'],
        user=DB_CONFIG['user'], password=DB_CONFIG.get('password',''),
        database=DB_CONFIG['database'], charset='utf8mb4', autocommit=True)
    return DB_CONN

def db_log(nivel, mensaje, consulta_id=None):
    try:
        conn = db_connect()
        with conn.cursor() as cur:
            cur.execute("INSERT INTO scraper_log (nivel, mensaje, consulta_id) VALUES (%s,%s,%s)",
                (nivel, mensaje[:500], consulta_id))
    except: pass

# ─── Driver ─────────────────────────────────────────────────────────────
def init_driver(headless=False, proxy=None):
    """Inicializa undetected-chromedriver — evita detección de bots."""
    import undetected_chromedriver as uc
    from selenium.webdriver.chrome.options import Options
    import shutil

    options = uc.ChromeOptions()
    options.add_argument('--no-first-run')
    options.add_argument('--no-default-browser-check')
    options.add_argument('--disable-infobars')
    options.add_argument('--disable-notifications')
    options.add_argument('--lang=es-CL')
    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_argument('--window-size=1366,768')
    options.add_argument(
        '--user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
        'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    )
    if proxy:
        options.add_argument(f'--proxy-server=socks5://{proxy}')

    # Buscar Chrome binary
    chrome_bin = (shutil.which('google-chrome-stable') or shutil.which('google-chrome')
                  or shutil.which('chromium-browser') or shutil.which('chromium')
                  or '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
    if os.path.exists(chrome_bin):
        options.binary_location = chrome_bin

    driver = uc.Chrome(options=options, headless=headless)

    # Anti-detección adicional
    driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {'source': '''
        Object.defineProperty(navigator, 'webdriver', {get:()=>undefined});
        Object.defineProperty(navigator, 'plugins', {get:()=>[1,2,3,4,5]});
        Object.defineProperty(navigator, 'languages', {get:()=>['es-CL','es','en']});
        Object.defineProperty(navigator, 'hardwareConcurrency', {get:()=>8});
        window.chrome = {runtime:{}};
    '''})
    return driver

# ─── Human simulation ──────────────────────────────────────────────────
def human_delay(min_s=None, max_s=None):
    mn = min_s or SCRAPER_CONFIG.get('min_delay_sec', 30)
    mx = max_s or SCRAPER_CONFIG.get('max_delay_sec', 90)
    d = random.uniform(mn, mx)
    log.info(f"⏳ Esperando {d:.0f}s...")
    time.sleep(d)

def random_mouse(driver):
    try:
        driver.execute_script("document.dispatchEvent(new MouseEvent('mousemove',{clientX:arguments[0],clientY:arguments[1],bubbles:true}));",
            random.randint(100,1200), random.randint(100,700))
    except: pass

def human_type(el, text):
    el.click(); time.sleep(random.uniform(0.1,0.3))
    for c in text: el.send_keys(c); time.sleep(random.uniform(0.03,0.15))
    time.sleep(random.uniform(0.2,0.5))

# ─── CAPTCHA ────────────────────────────────────────────────────────────
def resolver_captcha(driver):
    """Detecta y resuelve CAPTCHA. True = resuelto o no hay."""
    from selenium.webdriver.common.by import By
    try:
        driver.find_element(By.ID, 'ans')
        log.warning("⚠️  CAPTCHA detectado")

        # Intentar con cookies guardadas
        cf = SCRAPER_CONFIG.get('use_cookies_file','')
        if cf and os.path.exists(cf):
            with open(cf,'rb') as f: cookies = pickle.load(f)
            for ck in cookies:
                try: driver.add_cookie(ck)
                except: pass
            driver.refresh(); time.sleep(3)
            try:
                driver.find_element(By.ID, 'ans')
                log.error("Cookies no funcionaron")
                return False
            except:
                log.info("✅ Cookies resolvieron CAPTCHA")
                return True

        log.error("❌ No se pudo resolver. Usa: python3 pjud_scraper.py --save-cookies cookies.pkl")
        return False
    except:
        return True

# ─── Búsqueda ──────────────────────────────────────────────────────────
def buscar_en_tribunal(driver, nombre, tribunal_codigo, tribunal_tipo):
    """Busca nombre en un tribunal y extrae resultados."""
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait, Select
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.common.exceptions import TimeoutException

    resultados = []
    try:
        log.info(f"🌐 Navegando a OJV...")
        driver.get('https://oficinajudicialvirtual.pjud.cl/indexN.php')
        time.sleep(random.uniform(2,4))
        random_mouse(driver)
        driver.execute_script(f"window.scrollTo(0,{random.randint(50,200)});")

        if not resolver_captcha(driver):
            return None

        # Esperar formulario
        try:
            WebDriverWait(driver, 15).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, 'select[name="tribunal"], input[name="nombre"], #nombre'))
            )
        except TimeoutException:
            log.warning("Timeout formulario. Posible CAPTCHA.")
            driver.save_screenshot(str(BASE_DIR/'reports'/f'error_captcha_{int(time.time())}.png'))
            return None

        # Seleccionar tribunal
        for sel in ['select[name="tribunal"]','select[name="cbofiltro"]','select[id*="tribunal"]']:
            try:
                s = driver.find_element(By.CSS_SELECTOR, sel)
                Select(s).select_by_value(tribunal_codigo)
                time.sleep(random.uniform(0.5,1))
                break
            except: continue

        # Ingresar nombre
        inp = None
        for sel in ['input[name="nombre"]','input[id="nombre"]','input[placeholder*="nombre"]']:
            try:
                inp = driver.find_element(By.CSS_SELECTOR, sel)
                break
            except: continue
        if not inp:
            log.error("No se encontró campo nombre")
            driver.save_screenshot(str(BASE_DIR/'reports'/f'error_nombre_{int(time.time())}.png'))
            return None

        human_type(inp, nombre)
        time.sleep(random.uniform(0.5,1.5))
        random_mouse(driver)

        # Click buscar
        for sel in ['input[type="submit"]','button[type="submit"]','#buscar','input[value="Buscar"]']:
            try:
                driver.find_element(By.CSS_SELECTOR, sel).click()
                break
            except: continue
        else:
            try: driver.find_element(By.TAG_NAME,'form').submit()
            except:
                log.error("No se pudo enviar formulario")
                return None

        time.sleep(random.uniform(2,5))

        # Esperar tabla
        try:
            WebDriverWait(driver, 15).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, 'table, .tabla, .resultados, #resultados'))
            )
        except TimeoutException:
            txt = driver.find_element(By.TAG_NAME,'body').text.lower()
            if 'sin resultados' in txt or 'no se encontraron' in txt:
                log.info(f"Sin resultados para '{nombre}'")
                return []
            log.warning(f"No se encontró tabla para '{nombre}'")
            return []

        # Parsear
        for ts in ['table','.tabla','.resultados table','#resultados table']:
            try:
                tbl = driver.find_element(By.CSS_SELECTOR, ts)
                for row in tbl.find_elements(By.TAG_NAME,'tr')[1:]:
                    cells = row.find_elements(By.TAG_NAME,'td')
                    if len(cells) >= 3:
                        resultados.append({
                            'rit': cells[0].text.strip(),
                            'caratulado': cells[1].text.strip() if len(cells)>1 else '',
                            'estado': cells[2].text.strip() if len(cells)>2 else '',
                            'fecha_ingreso': cells[3].text.strip() if len(cells)>3 else '',
                            'tribunal_nombre': cells[4].text.strip() if len(cells)>4 else '',
                            'raw_html': row.get_attribute('outerHTML')[:5000]
                        })
                if resultados:
                    log.info(f"📋 {len(resultados)} causas para '{nombre}' en {tribunal_codigo}")
                    break
            except: continue

        return resultados

    except Exception as e:
        log.error(f"Error búsqueda: {e}")
        log.error(traceback.format_exc())
        try: driver.save_screenshot(str(BASE_DIR/'reports'/f'error_{int(time.time())}.png'))
        except: pass
        return None

# ─── Queue ──────────────────────────────────────────────────────────────
def get_pending_jobs(limit=5):
    conn = db_connect()
    with conn.cursor() as cur:
        cur.execute("""
            SELECT c.id, c.search_name_id, c.tribunal_id, sn.nombre, t.codigo, t.tipo
            FROM consultas c
            JOIN search_names sn ON c.search_name_id = sn.id
            JOIN tribunales t ON c.tribunal_id = t.id
            WHERE c.estado='pendiente' AND sn.activo=1 AND t.activo=1
              AND c.intentos < %s
            ORDER BY sn.prioridad ASC, c.id ASC LIMIT %s
        """, (SCRAPER_CONFIG.get('max_intentos',3), limit))
        return cur.fetchall()

def save_resultados(consulta_id, resultados):
    conn = db_connect(); now = datetime.datetime.now()
    with conn.cursor() as cur:
        cur.execute("UPDATE consultas SET estado='completado',fecha_consulta=%s,intentos=intentos+1 WHERE id=%s", (now,consulta_id))
        saved = 0
        for r in resultados:
            if r['rit']:
                cur.execute("SELECT id FROM resultados_causas WHERE rit=%s", (r['rit'],))
                if cur.fetchone(): continue
            cur.execute("""INSERT INTO resultados_causas (consulta_id,rit,caratulado,tribunal_nombre,estado,fecha_ingreso,raw_html)
                VALUES (%s,%s,%s,%s,%s,%s,%s)""",
                (consulta_id, r.get('rit',''), r.get('caratulado',''), r.get('tribunal_nombre',''),
                 r.get('estado',''), r.get('fecha_ingreso',None), r.get('raw_html','')))
            saved += 1
        if saved: log.info(f"💾 {saved} resultados guardados")

def marcar_error(consulta_id, msg):
    conn = db_connect()
    with conn.cursor() as cur:
        cur.execute("UPDATE consultas SET estado='error',error_msg=%s,intentos=intentos+1 WHERE id=%s", (msg[:500],consulta_id))
    db_log('error', msg, consulta_id)

def marcar_sin_resultados(consulta_id):
    conn = db_connect()
    with conn.cursor() as cur:
        cur.execute("UPDATE consultas SET estado='sin_resultados',intentos=intentos+1 WHERE id=%s", (consulta_id,))

# ─── Daemon ─────────────────────────────────────────────────────────────
def run_daemon():
    log.info("🔄 Iniciando modo daemon")
    driver = None
    try:
        driver = init_driver(headless=SCRAPER_CONFIG.get('headless',False), proxy=SCRAPER_CONFIG.get('proxy_socks5',None))
        while True:
            jobs = get_pending_jobs(limit=SCRAPER_CONFIG.get('tribunales_por_ronda',3))
            if not jobs:
                log.info("✅ Sin pendientes. Esperando 5 min...")
                time.sleep(300); continue
            for j in jobs:
                cid, snid, tid, nom, cod, tipo = j
                log.info(f"🔍 '{nom}' en {cod} ({tipo})")
                try:
                    res = buscar_en_tribunal(driver, nom, cod, tipo)
                    if res is None: marcar_error(cid, "Error búsqueda")
                    elif len(res)==0: marcar_sin_resultados(cid)
                    else: save_resultados(cid, res)
                    human_delay()
                except Exception as e:
                    marcar_error(cid, str(e)[:500]); human_delay(60,120)
            human_delay(120,300)
    except KeyboardInterrupt: log.info("👋 Detenido")
    except Exception as e: log.critical(f"Fatal: {e}"); log.critical(traceback.format_exc())
    finally:
        if driver:
            try: driver.quit()
            except: pass
        log.info("Terminado.")

# ─── Main ──────────────────────────────────────────────────────────────
def main():
    p = argparse.ArgumentParser(description='PJUD Scraper')
    p.add_argument('--name','-n', help='Buscar nombre específico')
    p.add_argument('--tribunal','-t', help='Código tribunal')
    p.add_argument('--daemon','-d', action='store_true', help='Modo demonio')
    p.add_argument('--test', action='store_true', help='Probar conexión')
    p.add_argument('--headless', action='store_true', help='Sin interfaz')
    p.add_argument('--save-cookies', help='Guardar cookies a archivo')
    args = p.parse_args()

    if args.test:
        log.info("🧪 Probando conexión...")
        driver = init_driver(headless=args.headless or SCRAPER_CONFIG.get('headless',False))
        try:
            driver.get('https://oficinajudicialvirtual.pjud.cl/indexN.php')
            time.sleep(5)
            log.info(f"✅ Página: {driver.title or driver.current_url}")
            driver.save_screenshot(str(BASE_DIR/'reports'/'test.png'))
            body = driver.find_element('tag name','body').text[:300]
            if 'captcha' in body.lower() or 'human' in body.lower() or 'bottle' in body.lower():
                log.warning("⚠️  CAPTCHA detectado. Necesitas --save-cookies con sesión manual.")
            else:
                log.info("✅ Sin CAPTCHA. Listo!")
                with open(str(BASE_DIR/'reports'/'test_page.html'),'w') as f:
                    f.write(driver.page_source)
        finally:
            driver.quit()
        return

    if args.save_cookies:
        log.info(f"🍪 Guardando cookies a {args.save_cookies}")
        driver = init_driver(headless=False)
        try:
            driver.get('https://oficinajudicialvirtual.pjud.cl/indexN.php')
            input("🔵 Resuelve CAPTCHA manual en el navegador y presiona Enter...")
            with open(args.save_cookies,'wb') as f:
                pickle.dump(driver.get_cookies(), f)
            log.info(f"✅ Cookies guardadas en {args.save_cookies}")
        finally:
            driver.quit()
        return

    if args.daemon:
        run_daemon(); return

    if args.name:
        log.info(f"🔍 '{args.name}'")
        driver = init_driver(headless=args.headless or SCRAPER_CONFIG.get('headless',False))
        try:
            res = buscar_en_tribunal(driver, args.name, args.tribunal or 'JGDO_GARANTIA_1_SANTIAGO', 'penal')
            if res:
                print(f"\n{'='*60}\nResultados para: {args.name}\n{'='*60}")
                for r in res:
                    print(f"  RIT: {r['rit']}\n  Caratulado: {r['caratulado']}\n  Estado: {r['estado']}\n  Ingreso: {r['fecha_ingreso']}\n{'─'*60}")
            else:
                print("Sin resultados o error.")
        finally:
            driver.quit()
        return

    run_daemon()

if __name__=='__main__':
    main()
