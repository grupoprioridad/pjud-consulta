#!/bin/bash
# =============================================
# Setup PJUD Scraper
# =============================================
set -e

echo "=== PJUD Scraper - Instalación ==="

# 1. Crear BD
echo "[1/4] Creando base de datos..."
mysql -u root < "$(dirname "$0")/db/schema.sql" 2>/dev/null || {
  echo "⚠️  No se pudo crear BD automáticamente."
  echo "   Ejecuta manualmente: mysql -u root < db/schema.sql"
}

# 2. Instalar dependencias Python
echo "[2/4] Instalando dependencias Python..."
pip3 install -r "$(dirname "$0")/scraper/requirements.txt" --break-system-packages 2>/dev/null || \
pip3 install -r "$(dirname "$0")/scraper/requirements.txt" 2>/dev/null || \
echo "⚠️  Instala manualmente: pip3 install -r scraper/requirements.txt"

# 3. Configurar Apache (si está disponible)
echo "[3/4] Configurando Apache..."
if command -v a2enmod &> /dev/null; then
  # Linux (Debian/Ubuntu)
  SITE_CONF="/etc/apache2/sites-available/pjud-scraper.conf"
  cat > "$SITE_CONF" << EOF
Alias /pjud-scraper $(dirname "$0")/web
<Directory $(dirname "$0")/web>
    Options Indexes FollowSymLinks
    AllowOverride All
    Require all granted
</Directory>
EOF
  a2ensite pjud-scraper.conf 2>/dev/null || true
  systemctl reload apache2 2>/dev/null || service apache2 reload 2>/dev/null || true
  echo "   Web disponible en: http://localhost/pjud-scraper/"
elif [ -d "/Applications/MAMP/conf/apache" ]; then
  # macOS con MAMP
  MAMP_WEB=$(dirname "$0")/web
  echo "   Para MAMP, copia o enlaza:"
  echo "   ln -s $MAMP_WEB /Applications/MAMP/htdocs/pjud-scraper"
  echo "   Web en: http://localhost:8888/pjud-scraper/"
else
  echo "   Apache no detectado. Sirve los archivos manualmente desde:"
  echo "   $(dirname "$0")/web/"
fi

# 4. Probar
echo "[4/4] Probando scraper..."
python3 "$(dirname "$0")/scraper/pjud_scraper.py" --test --headless 2>&1 | tail -5 || \
echo "⚠️  Prueba falló. Revisa que Chrome esté instalado."

echo ""
echo "=== Instalación completa ==="
echo "📁 Proyecto: $(dirname "$0")"
echo "🌐 Web: http://localhost/pjud-scraper/"
echo ""
echo "Próximos pasos:"
echo "1. Agrega nombres desde la web"
echo "2. Guarda cookies: python3 scraper/pjud_scraper.py --save-cookies cookies.pkl"
echo "3. Ejecuta: python3 scraper/pjud_scraper.py --daemon"
