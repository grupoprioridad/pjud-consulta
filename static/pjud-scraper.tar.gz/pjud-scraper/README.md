# PJUD Scraper — Buscador Automático de Causas Judiciales

Sistema para buscar nombres en la Oficina Judicial Virtual del Poder Judicial de Chile,
a través de tribunales **Penales**, **Familia** y **Cortes de Apelaciones**.

## Arquitectura

```
pjud-scraper/
├── web/                 # Interfaz web (PHP + Bootstrap 5)
│   ├── index.php        # Dashboard con estadísticas
│   ├── names.php        # CRUD de nombres a buscar
│   ├── results.php      # Vista de causas encontradas
│   ├── reports.php      # Reportes + gráficos (Chart.js)
│   ├── export.php       # Exportación CSV
│   └── config.php       # Conexión MySQL
├── scraper/
│   ├── pjud_scraper.py  # Scraper principal (Python)
│   └── requirements.txt # Dependencias Python
├── db/
│   └── schema.sql       # Esquema MySQL
├── config/
│   └── config.json      # Configuración general
└── reports/             # Screenshots, logs, exportaciones
```

## Requisitos

- Python 3.9+
- Google Chrome o Chromium
- MySQL 5.7+ / MariaDB 10+
- PHP 8.0+ (para la web)
- Apache o nginx (para la web)

## Instalación Rápida

```bash
# 1. Clonar / copiar el proyecto
cd /var/www/pjud-scraper

# 2. Instalar dependencias Python
pip3 install -r scraper/requirements.txt

# 3. Crear base de datos
mysql -u root < db/schema.sql

# 4. Configurar acceso DB en config/config.json
nano config/config.json

# 5. Probar conexión
python3 scraper/pjud_scraper.py --test

# 6. Guardar cookies (primera vez, resuelve CAPTCHA manual)
python3 scraper/pjud_scraper.py --save-cookies cookies.pkl

# 7. Agregar nombres desde la web o CLI
# Web: abrir http://localhost/pjud-scraper/
# CLI: python3 scraper/pjud_scraper.py --save-cookies cookies.pkl
#      y luego python3 scraper/pjud_scraper.py --daemon
```

## Uso

### CLI

```bash
# Probar conexión
python3 scraper/pjud_scraper.py --test

# Guardar cookies (resolver CAPTCHA manual una vez)
python3 scraper/pjud_scraper.py --save-cookies cookies.pkl

# Buscar un nombre específico
python3 scraper/pjud_scraper.py --name "Juan Pérez"

# Modo demonio (loop automático procesando cola)
python3 scraper/pjud_scraper.py --daemon

# Sin interfaz gráfica
python3 scraper/pjud_scraper.py --daemon --headless

# Con proxy SOCKS5 (túnel SSH)
python3 scraper/pjud_scraper.py --daemon
# Luego configurar proxy en config.json: "proxy_socks5": "127.0.0.1:1080"
```

### Web

Abrir en el navegador: `http://localhost/pjud-scraper/`

1. **Dashboard** → estadísticas generales, últimas causas
2. **Nombres** → agregar/quitar nombres para buscar
3. **Resultados** → filtrar y ver causas encontradas
4. **Reportes** → gráficos y exportación CSV

## Túnel SSH (para pruebas desde servidor cloud)

Si quieres que el scraper corra desde un servidor cloud pero evite el CAPTCHA
(que aparece por IP de datacenter), puedes tunnelizar tu conexión residencial:

```bash
# En tu Mac/local (el que tiene IP chilena residencial):
ssh -D 1080 -N tu-servidor.com

# O con autossh para que sea persistente:
autossh -M 0 -o "ServerAliveInterval 60" -o "ServerAliveCountMax 3" \
  -D 1080 -N tu-servidor.com

# Luego configurar en config.json del servidor:
# "proxy_socks5": "127.0.0.1:1080"
```

## Estructura de la DB

| Tabla | Descripción |
|-------|-------------|
| `search_names` | Nombres a buscar (con RUT opcional, prioridad) |
| `tribunales` | Catálogo de 30+ tribunales chilenos |
| `consultas` | Registro de cada búsqueda ejecutada |
| `resultados_causas` | Causas encontradas (RIT, caratulado, estado) |
| `reportes` | Reportes generados |
| `scraper_log` | Log de actividad del scraper |

## Tribunales incluidos (30+)

- **Penal**: Juzgados de Garantía de Santiago (1° al 7°), TOP Santiago,
  Garantía de Viña, Valparaíso, Concepción, Temuco, Rancagua, Talca, etc.
- **Familia**: 1° al 3° Juzgado de Familia de Santiago, Viña, Valpo, Concepción, etc.
- **Cortes**: Corte Suprema, Cortes de Apelaciones (Santiago, San Miguel,
  Valparaíso, Concepción, Rancagua, etc.)

## Simulación Humana

El scraper incorpora:
- Pausas aleatorias entre 30-90 segundos entre búsquedas
- Velocidad de tipeo variable (simula escritura humana)
- Movimientos de mouse aleatorios vía JS
- Scrolls aleatorios
- User-Agent realista
- Rotación de tiempos

## CAPTCHA

El sitio usa Trusteer (IBM). La primera vez:
1. Ejecuta `python3 scraper/pjud_scraper.py --save-cookies cookies.pkl`
2. Se abrirá Chrome, resuelve el CAPTCHA manualmente
3. Las cookies se guardan para futuras ejecuciones

## Licencia

Uso interno — Proyecto de Esteban Hernández
